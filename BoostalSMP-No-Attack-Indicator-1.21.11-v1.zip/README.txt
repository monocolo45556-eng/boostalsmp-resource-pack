BoostalSMP No Attack Indicator

This Java resource pack hides the vanilla attack cooldown indicator in both
crosshair and hotbar modes. It only changes HUD textures; server-side combat
logic and spear cooldown enforcement remain unchanged.

Target: Minecraft Java Edition 1.21.11 (resource pack format 75.0)
