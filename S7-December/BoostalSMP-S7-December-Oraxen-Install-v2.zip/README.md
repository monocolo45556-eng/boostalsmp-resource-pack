# December Monthly Oraxen Overlay

Install the item YAML under plugins/Oraxen/items/ and merge the pack/ directory with the existing Oraxen pack. These are real cuboid models and referenced texture atlases extracted from the supplied Christmas 2025 source archive. The seven supplied PNGs are Bedrock inventory icons and are intentionally not used as Java/Oraxen model textures.
